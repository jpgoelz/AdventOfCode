adr new First Record
adr new Second Record
adr new -s 1 -s 2 Third Record
head -8 doc/adr/0001-first-record.md
head -8 doc/adr/0002-second-record.md
head -12 doc/adr/0003-third-record.md
