adr new The First Decision
cat doc/adr/0001-the-first-decision.md
