adr init
ls doc/adr
cat doc/adr/0001-record-architecture-decisions.md
