adr new Something About Node.JS
adr new Slash/Slash/Slash/
adr new -- "-Bar-"
ls doc/adr
