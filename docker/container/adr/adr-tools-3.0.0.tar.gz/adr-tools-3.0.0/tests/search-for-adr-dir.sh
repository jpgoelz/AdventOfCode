adr new First Record
mkdir subdir
cd subdir
adr new Second Record
adr list
cd ..
adr list
