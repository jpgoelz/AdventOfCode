adr new First Record
adr new -s 1 Second Record
head -10 doc/adr/0001-first-record.md
head -12 doc/adr/0002-second-record.md

