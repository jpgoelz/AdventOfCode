adr init
(
	ADR_DATE=12/01/1992
	adr new With Old Date Format
)
adr new With Current Date Format
grep Date: doc/adr/*
adr upgrade-repository
grep Date: doc/adr/*
