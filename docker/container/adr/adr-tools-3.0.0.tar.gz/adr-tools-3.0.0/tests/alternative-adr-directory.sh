adr init alternative-dir
adr new Example ADR

ls .
ls alternative-dir

adr list
